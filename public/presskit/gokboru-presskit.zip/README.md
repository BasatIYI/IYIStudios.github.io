# GÖKBÖRÜ — PRESS KIT & FACT SHEET

## Basic Information
- **Title:** Gökbörü
- **Developer:** IYI Studios
- **Publisher:** IYI Studios
- **Location:** Türkiye
- **Platform:** PC (Windows — Steam)
- **Release Date:** Coming Soon (TBA)
- **Genres:** 3D Arcade Action, Territory Capture, Adventure, Strategy, Indie
- **Input Support:** Keyboard & Gamepad

## Official Links
- **Steam Store Page:** https://store.steampowered.com/app/4886790/Gokboru/
- **Official Website:** https://www.iyistudios.com/gokboru
- **Studio Website:** https://www.iyistudios.com
- **YouTube:** https://www.youtube.com/@iyigames6606
- **X (Twitter):** https://x.com/IYIStudios
- **Instagram:** https://www.instagram.com/iyistudios
- **Facebook:** https://www.facebook.com/iyigamesmete

---

## Short Description (Pitch)
Draw lines, claim territory and cleanse the land of Erlik's demons in this 3D arcade action game rooted in Turkic mythology. Outsmart minions, survive mythic bosses and chase high scores — every capture is a risk, every close call a rush.

---

## About the Game
**Draw the Line. Claim the Land. Cleanse the Darkness.**

**Gökbörü** is a 3D arcade action game about **territory capture**, set in Turkish and Central Asian (Turkic) mythology. Leave safe ground, sweep a line across the arena and close it to claim the land for yourself. But every open line is a gamble: Erlik's demons are hunting, and one touch can end your run.

### The Story
Erlik, Lord of the Underworld, has broken through to the surface. His shadow demons, the Körmös, crawl across the earth and corrupt everything they touch.

You fight back as **Kızagan**, the legendary hero of the prologue, and as **Baybörü**, commander of the Gökbörü, the Celestial Wolf's army. Bürküt, messenger of the sky god Ülgen, guides your way. Every chapter is framed by cinematic story cutscenes told in the spirit of the Dede Korkut epics, and you can rewatch them anytime from the Story Gallery.

### Key Features
- **Draw to Claim:** Sweep a line through the arena and close it back onto your territory. Everything you enclose is cleansed.
- **Risk vs. Reward:** Small captures are safe and steady. Big captures score far more and build combo multipliers, but the longer your line stays open, the more exposed you are.
- **Open Lines Ignite:** When an enemy touches your unfinished line, danger races along the trail toward you. Close the loop in time, or use a well-timed deflect to survive.
- **Crush the Horde:** Seal the ground beneath a Körmös minion to destroy it, or pick minions off with arrows and spears.
- **Power-Ups:** Claim the land around power boxes to unlock Speed Boost, Freeze, Bow & Arrows, piercing Spears, Clear Minions, Extra Lives, and Bonus Points.
- **Mythic Boss Battles:** Every realm ends with a legendary figure from Turkic mythology — including **Tepegöz**, **Alkarısı**, **Karabasan**, **Abra & Yutpa**, **Kara Şaman**, **Temir Han and his Eight Sons**, and **Erlik Han**.
- **Handcrafted 3D Arenas:** Fight across haunted trade roads, ruined cities, the Underworld gate, and Erlik's throne room, accompanied by an atmospheric soundtrack.

---

## System Requirements (PC)

### Minimum
- **OS:** Windows 10 (64-bit)
- **Processor:** Intel Core i3-6100 / AMD Ryzen 3 1200
- **Memory:** 8 GB RAM
- **Graphics:** NVIDIA GeForce GTX 960 / AMD Radeon RX 470 (2 GB VRAM)
- **DirectX:** Version 11
- **Storage:** 4 GB available space

### Recommended
- **OS:** Windows 10 / 11 (64-bit)
- **Processor:** Intel Core i5-8400 / AMD Ryzen 5 2600
- **Memory:** 16 GB RAM
- **Graphics:** NVIDIA GeForce GTX 1060 / AMD Radeon RX 580 (4 GB+ VRAM)
- **DirectX:** Version 11
- **Storage:** 4 GB available space

---

## About IYI Studios
IYI Studios is an independent game studio from Türkiye creating games with soul and atmosphere across PC and mobile platforms, including mobile titles Galaxy Go, Color Sticks, Rolldrop, Tetrigun, and its first major PC title, Gökbörü.
