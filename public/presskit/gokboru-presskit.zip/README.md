# GÖKBÖRÜ — PRESS KIT & FACT SHEET

## Basic Information
- **Title:** Gökbörü
- **Developer:** IYI Studios
- **Publisher:** IYI Studios
- **Location:** Türkiye
- **Platform:** PC (Windows — Steam)
- **Release Date:** March 2027 (Free Prologue Demo coming soon on Steam)
- **Genres:** Action, Roguelite, Arcade, Top-Down, Mythology, Indie
- **Input Support:** Keyboard & Gamepad

## Official Links
- **Steam Store Page:** https://store.steampowered.com/app/4886790/Gokboru/
- **Official Trailer:** https://youtu.be/r_IZLDmio_w
- **Boss Reveal Trailer:** https://youtu.be/swHfokx1yrA
- **Visual Update Trailer:** https://youtu.be/JaGRAbsxZEY
- **Discord Community:** https://discord.gg/wbyRSjavpX
- **Official Website:** https://www.iyistudios.com/gokboru
- **Turkish Website:** https://www.iyistudios.com/tr/gokboru
- **Studio Website:** https://www.iyistudios.com
- **YouTube:** https://www.youtube.com/@iyigames6606
- **X (Twitter):** https://x.com/IYIStudios
- **Instagram:** https://www.instagram.com/iyistudios
- **Facebook:** https://www.facebook.com/iyigamesmete

---

## Short Description (Pitch)
Draw a line, close the loop, crush every demon caught inside. A 3D arcade action roguelite born from Turkic mythology — every open line is a gamble. Power up with 18 divine Boons, unlock 6 synergies and chase the high score.

---

## About the Game
**Draw the Line. Claim the Land. Cleanse the Darkness.**

**Gökbörü** is a 3D tactical territory-capture action roguelite set in Turkish and Central Asian (Turkic) mythology. Leave safe ground, sweep a line across the arena and close it to claim the land for yourself. But every open line is a gamble: Erlik's demons are hunting, and one touch ignites your trail.

### The Story
Erlik, Lord of the Underworld, has broken through to the surface. His shadow demons, the Körmös, crawl across the earth and corrupt everything they touch.

You fight back as **Kızagan**, the legendary hero of the prologue, and as **Baybörü**, commander of the Gökbörü, the Celestial Wolf's army. Bürküt, messenger of the sky god Ülgen, guides your way across haunted trade roads, ruined cities, the Underworld gate and Erlik's throne room.

### Key Features
- **Draw to Claim:** Sweep a line through the arena and close it back onto your territory. Everything you enclose is cleansed. Purge at least 90% of the arena to triumph.
- **18 Divine Boons & 6 Duo Synergies:** Shape distinct builds each run with elemental synergies like Celestial Wolf, Iron Fortress, Solar Conquest, Sky Archer's Wrath, Eternal Ayaz and Storm of the Steppe. Reroll fates with Umay's blessing.
- **Chapter 1: Haunted Trade Road & Peri Kızı:** Venture into the sun-scorched oasis sanctuary. Morph into the Winged Wolf with custom celestial trails, deflect flying fairy blades, dodge deadly line-lunges, and unleash the cleansing fountain wave.
- **Shrine of Kut (8 Permanent Upgrades):** Spend sacred Kut gathered across runs at the ancient stone Shrine of Kut to unlock 8 permanent upgrades, and analyze past runs in the Chronicle.
- **10 Mythic Boss Battles:** Confront legendary figures from Turkic mythology — each testing a specific flaw: Peri Kılıcı, Tepegöz, Alkarısı, Karabasan, Yel Büke, Abra & Yutpa, Kara Şaman, Erlik Kızları, Temir Han, and the Lord of the Underworld, Erlik Han.
- **Cinematic Epics in Dede Korkut's Spirit:** Fight as Kızagan and Baybörü, guided by Bürküt across handcrafted top-down arenas with cutscenes that can be rewatched anytime in the Story Gallery.

---

## System Requirements (PC)

### Minimum
- **OS:** Windows 10 64-bit
- **Processor:** Intel Core i5-6500 / AMD Ryzen 3 1300X (4-core)
- **Memory:** 8 GB RAM
- **Graphics:** NVIDIA GTX 1050 Ti 4 GB / AMD RX 570 4 GB
- **DirectX:** Version 11
- **Storage:** 4 GB available space
- **Notes:** 1080p, Low/Balanced quality

### Recommended
- **OS:** Windows 10/11 64-bit
- **Processor:** Intel Core i5-9400 / AMD Ryzen 5 3600
- **Memory:** 16 GB RAM
- **Graphics:** NVIDIA GTX 1660 Super / AMD RX 5600 XT (6 GB)
- **DirectX:** Version 12
- **Storage:** 4 GB available space (SSD)
- **Notes:** 1080p, High quality, 60 FPS

---

## About IYI Studios
IYI Studios is an independent game studio from Türkiye creating games with soul and atmosphere across PC and mobile platforms, including mobile titles Galaxy Go, Color Sticks, Rolldrop, Tetrigun, and its first major PC title, Gökbörü.